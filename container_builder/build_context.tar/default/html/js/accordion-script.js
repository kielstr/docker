$(document).ready(function() {
  
  $("#accordion").accordion({
  			collapsible: true,
  			active: false,
  			autoHeight: false
  		});

});