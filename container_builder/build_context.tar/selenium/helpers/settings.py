from fixtures.surveys import *

# this needs to be usdated depending on which survey you wanna test
survey_folder = "university-melbourne"
survey = "link-me"



# general settings
baseurl = surveys[survey_folder][survey]["url"]
username = surveys[survey_folder][survey]["username"]
password = surveys[survey_folder][survey]["password"]

button = {
    "next" : "#action-next",
    "prev" : "#action-prev",
    "home" : "#action-parent",
}

WebDriverWaitSeconds = 20
sleepSeconds = 1
