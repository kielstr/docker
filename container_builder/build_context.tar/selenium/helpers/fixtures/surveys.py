# List of all testable surveys
# Keep adding to the link when you have new surveys

surveys = {
    "university-melbourne" : {
      "link-me": {
        "username"  : "t3",
        "password"  : "qV3@hL74",
        "url"       : 'https://university-melbourne.staging.websurvey.net.au/link-me/',
      }
    }
}
